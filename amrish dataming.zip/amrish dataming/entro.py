
import random as r
import math as m

y = []
ent = []

for i in range(20):
    y.append(r.randint(0,1))

for i in range(2):
     ent.append((-(y.count(i)/len(y)) * m.log((y.count(i)/len(y)),2) - ((20-y.count(i))/len(y)) * m.log((20-y.count(i),2))/len(y)))
    