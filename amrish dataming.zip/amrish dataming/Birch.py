import numpy as np
import matplotlib.pyplot as plt
import Birch

plt.rcParams['figure.figsize']=(8,8)

Data = np.load('Data' + '.npy')
labels = np.load('labels' + '.npy')
print(Data.shape)

branching_factor_val=200
threshold_val=0.5


brc = Birch(branching_factor=branching_factor_val, n_clusters=3, threshold=threshold_val,compute_labels=True)
brc.fit(Data)
unique_predicted_labels = np.unique(predicted_labels)
print(unique_predicted_labels)


n_clusters = len(unique_predicted_labels)

colors = ['k', 'g', 'r', 'y', 'b','r']

fig = plt.figure(figsize=(8, 8))
ax = fig.add_subplot(1, 1, 1)
for k, col in zip(range(-1,n_clusters), colors):
    my_members = predicted_labels == k
    ax.plot(Data[my_members, 0], Data[my_members, 1], 'x',
            markerfacecolor=col, marker='*')
ax.set_title("Birch")
plt.show()