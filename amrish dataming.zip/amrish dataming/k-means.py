import numpy as np
from sklearn.cluster import KMeans
import pandas as pd


df=pd.read_csv("data.csv")
df.head()

f1 = df['Distance_Feature'].values
f2 = df['Speeding_Feature'].values

X=np.matrix(zip(f1,f2))
kmeans = KMeans(n_clusters=2).fit(X)