import pandas as pd
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules

df = pd.read_excel('Online Retail.xlsx')
df.head()
te = TransactionEncoder()
te_ary = te.fit(odf).transform(odf)
odf = pd.DataFrame(te_ary, columns=te.columns_)
print(odf,"\n") 