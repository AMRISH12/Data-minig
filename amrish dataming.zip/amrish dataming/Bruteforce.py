import itertools as it

itemset=['shoes','shirt','jacket','jeans','sweetshirt']
transection=[['shoes','shirt','jacket'],['shoes','jacket'],['shoes','jeans'],['shirt','sweetshirt']]
support_thres=0.5
confidence_thres=0.5

def support(l):
    lst = []
    count = 0
    for i in range(len(transection)):
        t = 1
        for j in l:
            if(j not in transection[i]):
                t = 0
        if(t==1):
            count = count + 1
    return round((count/len(transection)),2)


y=[]

for i in range(1,len(itemset)+1):
    j = it.combinations(itemset,i)
    for k in j:
        y.append(list(k))
print("All possible Combinations are:")
for i in y:
    print(i)
    
freq_item=[]
for i in y:
    if(support(i)>=support_thres):
        freq_item.append(i)

print("\n\nFrequent Set:", freq_item)  

