import random as r

a = ['a','b','c','d','e']
x = []
y = []

tr_set = []
tr_l =[]

ts_set = []
ts_l = []

for i in range(2):
    x.append([])
    for j in range(5):
        x[i].append(r.choice(a))

for i in range(5):
    y.append(r.randint(0,2))

test = r.sample(range(0,5), 5)

for i in range(2):
    tr_set.append([])
    for j in range(3):
        tr_set[i].append(x[i][test[j]])

for i in range(3):
    tr_l.append(y[test[i]])



