import numpy as np
from sklearn.cluster import AgglomerativeClustering
from datetime import datetime

startTime = datetime.now()

Data = np.load('Data' + '.npy')
labels = np.load('labels' + '.npy')
print(Data.shape)
unique_labels = np.unique(labels)
print(unique_labels)

cluster = 3

AggC = AgglomerativeClustering(n_clusters=cluster, affinity ='euclidean', linkage='average')
AggC.fit(Data)
AggC.fit_predict(Data)
predicted_labels = AggC.labels_
unique_predicted_labels = np.unique(predicted_labels)
print(unique_predicted_labels)

print("Algorithm Running Time: ")
print (datetime.now() - startTime)


#from sklearn.metrics import confusion_matrix
#confusion_matrix(labels,predicted_labels)

############################################
"""silhouette_score"""
from sklearn.metrics import silhouette_score
silhouette_value = silhouette_score(Data, predicted_labels, metric='euclidean')

#########################################
''' homogeneity_completeness_v_measure '''
from sklearn.metrics.cluster import homogeneity_completeness_v_measure
score = homogeneity_completeness_v_measure(labels,predicted_labels)


#########################################
import matplotlib.pyplot as plt
n_clusters = cluster
colors = ['b', 'g', 'r', 'y', 'k']
###########################################
"""plot reasults."""

fig = plt.figure(figsize=(8, 3))
ax = fig.add_subplot(1, 3, 1)
for k, col in zip(range(n_clusters), colors):
    my_members = predicted_labels == k
    ax.plot(Data[my_members, 0], Data[my_members, 1], 'w',
            markerfacecolor=col, marker='.')
ax.set_title("Spectral Clustering")
ax.set_xticks(())
ax.set_yticks(())
plt.show()