import math as m

def gini(pi):
    total=1
    for p in pi:
        total=total-m.pow(p/sum(pi),2)
    return round(total,2)
gini([9,5])
