from __future__ import division
from math import log


def entropy(pi):
    total = 0
    for p in pi:
        p = p / sum(pi)
        if p != 0:
            total += p * log(p, 2)
        else:
            total += 0
    total *= -1
    return total
  
    
def gain(d, a):

    total = 0
    for v in a:
        total += sum(v) / sum(d) * entropy(v)

    gain = entropy(d) - total
    return gain



shapecolor = [9, 5] # Yes, No

# attribute, number of members (feature)
color = [
    [2, 3],  # green
    [4, 0],  # yellow
    [3, 2]   # red
]
outline = [
    [3, 4],  # dashed
    [6, 1],  # solid
    ]
dot = [
    [3, 3],  # yes
    [6, 2]   # no
]

print("entropy of shape",entropy(shapecolor))
print("gain of color:=",gain(shapecolor,color))
print("gain of outline:=",gain(shapecolor, outline))
print("gain of dot:=",gain(shapecolor, dot))
