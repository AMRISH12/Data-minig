import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from datetime import datetime

startTime = datetime.now()

Data = np.load('Data' + '.npy')
labels = np.load('labels' + '.npy')
print(Data.shape)
unique_labels = np.unique(labels)
print(unique_labels)

cluster = 5
#############
"""Computing K-Means algorithm"""
k_means = KMeans(n_clusters=cluster, init='random', n_init=1)
k_means.fit(Data)
predicted_labels = k_means.labels_
centroids = k_means.cluster_centers_
unique_predicted_labels = np.unique(predicted_labels)
within_cluster_distance = k_means.inertia_

print("Algorithm Running Time: ")
print (datetime.now() - startTime)
###################################
"""confusion Matrix"""
#from sklearn.metrics import confusion_matrix
#confusion_matrix_score = confusion_matrix(labels,predicted_labels)
#print(confusion_matrix_score)

#######################################
""" Homoginity Score """
#from sklearn.metrics.cluster import homogeneity_score
#score = homogeneity_score(labels,predicted_labels)


############################################
"""silhouette_score"""
from sklearn.metrics import silhouette_score
silhouette_value = silhouette_score(Data, predicted_labels, metric='euclidean')

#########################################
''' homogeneity_completeness_v_measure '''
from sklearn.metrics.cluster import homogeneity_completeness_v_measure
score = homogeneity_completeness_v_measure(labels,predicted_labels)

# #####################################
n_clusters = cluster
colors = ['b', 'g', 'r', 'y', 'k']
###########################################
"""plot reasults."""

fig = plt.figure(figsize=(8, 3))
ax = fig.add_subplot(1, 3, 1)
for k, col in zip(range(n_clusters), colors):
    my_members = predicted_labels == k
    cluster_center = centroids[k]
    ax.plot(Data[my_members, 0], Data[my_members, 1], 'w',
            markerfacecolor=col, marker='.')
    ax.plot(cluster_center[0], cluster_center[1], 'o', markerfacecolor=col,
                                    markeredgecolor='k', markersize=6)
ax.set_title("KMeans")
ax.set_xticks(())
ax.set_yticks(())
plt.show()