import random
import numpy as np
tr = []
test = []

data_at= np.random.randint(low=1,high=100,size=(100,5))
#print(data_at)
data_ind=np.random.randint(low=0,high=99,size=100)
#print(data_ind)
print('how much % data r u want to train ur model\n',end="" )
rg = int(input())
for i in range(0,rg):
    tr.append(data_at[i])
    tr.append(data_ind[i])
    

print("training dataset is :- ")
print(tr)
print("\n")
for i in range(rg,100):
    test.append(data_at[i])
    test.append(data_ind[i])
    
 

print("testing dataset :- ")

print(test)
    