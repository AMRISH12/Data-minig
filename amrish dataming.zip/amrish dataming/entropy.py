
import pandas as pd
import nltk
import math
df = pd.read_csv('playTennis.csv')
print(df)
def entropy(df,lable):
    n = []
    l = []
    a = (nltk.FreqDist(df[lable]).values())
    for i in a:
        n.append(i)
    #print(n)
    
#E(s) = -p1log2p1-plog2p
    total = len(df[lable])
    for i in range(len(n)):
        p = (n[i]/total)
        E = (-p)*(math.log2(p))
        l.append(E)
    su = sum(l) 
 ##entropy       
    return su
   
    
def Gain(df,subclass,lable):
    
# firstly find the entopy of zoner in particular columns
    nltk.FreqDist(df[subclass])
    # n is list of total of each zoner
    n = []
    # l is the list of unique zoner
    l = []
    #z is the list for each zoner entropy
    z = []
    a = (nltk.FreqDist(df[subclass]).values())
    for i in a:
        n.append(i)
    b = (nltk.FreqDist(df[subclass]).keys())
    for i in b:
        l.append(i)
    #print(n)
    #print(l)
    #y is the list of total of each zonar
    y = []
    #r is the list of data of zoners of particular colmn
    r = []
   
    for i in l:
        s = df.loc[df[subclass] == i ]
       # print(s)
        r.append(s)
   
        y.append(s[subclass].count())
       # y.append((nltk.FreqDist(s.play)).values())
   # print(r)   
   # print(y)
    gain = []
    total = sum(y)
    for i in range(len(l)):
        j = entropy(r[i],lable)
        
        gain.append(j)
   # print (gain[0])
    for i in range(len(l)):
       p = (n[i]/(total))*gain[i]
       z.append(p)
    Y = sum(z)
 # GA is the total gain of particular colmn         
    GA = entropy(df,'play') - Y
    return GA

##        

#entropy(s,'play')