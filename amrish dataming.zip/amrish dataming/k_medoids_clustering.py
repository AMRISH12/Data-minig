#!/usr/bin/python3 -i

#Suparn_Padma_Patra_2017MCCS009
#Importing modules
import random
import matplotlib.pyplot as plt
import numpy as np

#Global variable declaration
percentage_of_metoids = 10
total_number_of_points =20
Number_of_clusters = int((percentage_of_metoids*total_number_of_points)/100)
lower_point_limit = 1
upper_point_limit = 50


#Function to generate random points x and y coordinate points with cluster number
def generate_data():
    x_coordinate = []
    y_coordinate = []
    cluster_number_list = []
    cluster_number_list_new = []
    for i in range(total_number_of_points):
        x_coordinate.append(random.randint(lower_point_limit,upper_point_limit))
        y_coordinate.append(random.randint(lower_point_limit,upper_point_limit))
        cluster_number_list.append(0)
        cluster_number_list_new.append(0)
    return x_coordinate,y_coordinate,cluster_number_list,cluster_number_list_new

#Getting list of coordinate points with cluster number
x_coordinate,y_coordinate,cluster_number_list,cluster_number_list_new = generate_data()

#Initially generating the centroid for clustering
centroid = {}
for i in range(1,Number_of_clusters+1):
    temp_index = random.randint(0,len(x_coordinate)-1)
    centroid[i] = [x_coordinate[temp_index],y_coordinate[temp_index]] 
    cluster_number_list[temp_index] =  i

#Function to calculate Eucleadian distance
def calc_distance(index_of_centroid,index_of_point):
    x1 = centroid[index_of_centroid][0]
    y1 = centroid[index_of_centroid][1]
    
    x2 = x_coordinate[index_of_point]
    y2 = y_coordinate[index_of_point]

    distance_value = abs(y2-y1) + abs(x2-x1)
    return distance_value

def calc_cost(metoid_matrix):
    temp_min = []
    cost_matrix = []
    for i in range(len(metoid_matrix)):
        cost_matrix.append([])
    for i in range(len(x_coordinate)):
        temp_max = []
        for j in range(len(centroid)):
            temp_min.append(metoid_matrix[j][i])
        for j in range(len(centroid)):
            if min(temp_min) == metoid_matrix[j][i]:
                cost_matrix[j].append(metoid_matrix[j][i])
    
    cost = []
    for i in cost_matrix:
        cost.append(sum(i))
        
    return cost

metoid_matrix = []
for i in range(Number_of_clusters):
    metoid_matrix.append([])
    for j in range(len(x_coordinate)):
        metoid_matrix[i].append(calc_distance(i+1,j))
   
for i in range(len(x_coordinate)):
    temp_max = []
    for j in range(len(centroid)):
        temp_max.append(metoid_matrix[j][i])
    for j in range(len(centroid)):
        if max(temp_max) == metoid_matrix[j][i]:
            cluster_number_list[i] = j
cost = calc_cost(metoid_matrix)     
total_cost = sum(cost)

for k in range(100):
    centroid_new = {}
    for i in range(1,Number_of_clusters+1):
        temp_index = random.randint(0,len(x_coordinate)-1)
        centroid_new[i] = [x_coordinate[temp_index],y_coordinate[temp_index]] 
        cluster_number_list_new[temp_index] =  i

    metoid_matrix = []
    for i in range(Number_of_clusters):
        metoid_matrix.append([])
        for j in range(len(x_coordinate)):
            metoid_matrix[i].append(calc_distance(i+1,j))
    
    for i in range(len(x_coordinate)):
        temp_max = []
        for j in range(len(centroid_new)):
            temp_max.append(metoid_matrix[j][i])
        for j in range(len(centroid_new)):
            if max(temp_max) == metoid_matrix[j][i]:
                cluster_number_list_new[i] = j
    cost = calc_cost(metoid_matrix)     
    total_cost_new = sum(cost)

    if(total_cost_new > total_cost):
        centroid = centroid_new
        cluster_number_list = cluster_number_list_new

print("X Coordinate: ",x_coordinate)
print("Y Coordinate: ",y_coordinate)
    
print("Cluster Vector: ", cluster_number_list)


for i in range(len( cluster_number_list)):
    if (cluster_number_list[i]==0):
        plt.scatter(x_coordinate[i],y_coordinate[i],color='red')
    else:
        plt.scatter(x_coordinate[i],y_coordinate[i],color='green') 
        
        
        



