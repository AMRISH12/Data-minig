from math import log


def entropy(pi):
    total = 0
    for p in pi:
        p = p / sum(pi)
        if p != 0:
            total += p * log(p, 2)
        else:
            total += 0
    total *= -1
    return round(total,3)
    


def gain(d, a):

    total = 0
    for v in a:
        total += sum(v) / sum(d) * entropy(v)

    gain = entropy(d) - total
    return round(gain,3)



playTennis = [9, 5] # Yes, No

# attribute, number of members (feature)
outlook = [
    [4, 0],  # overcase
    [2, 3],  # sunny
    [3, 2]   # rain
]
temperature = [
    [2, 2],  # hot
    [3, 1],  # cool
    [4, 2]   # mild
]
humidity = [
    [3, 4],  # high
    [6, 1]   # normal
]
wind = [
    [6, 2],  # weak
    [3, 3]   # strong
]
tsunny=[2,3]

sunny_temperature = [
    [0, 2],  # hot
    [1, 1],  # cool
    [1, 0]   # mild
]
sunny_humidity = [
    [0, 3],  # high
    [2, 0]   # normal
]
sunny_wind = [
    [1, 2],  # weak
    [1, 1]   # strong
]
tovercast=[4,0] # yes,no
train=[3,2]   # yes,no

rain_temperature = [
    [2, 1],  # cool
    [1, 1]   # mild
]
rain_humidity = [
    [1, 1],  # high
    [2, 1]   # normal
]
rain_wind = [
    [3, 0],  # weak
    [0, 2]   # strong
]





print("entropy of playTennis",entropy(playTennis))
print("gain of outlook = ",gain(playTennis, outlook))
print("gain of temperature = ",gain(playTennis, temperature))
print("gain of humidity = ",gain(playTennis, humidity))
print("gain of wind = ",gain(playTennis, wind))
print("\n")
print("entropy of tsunny = ",entropy(tsunny))
print("gain of sunny_temperature = ",gain(tsunny, sunny_temperature))
print("gain of sunny_humidity = ",gain(tsunny, sunny_humidity))
print("gain of sunny_wind = ",gain(tsunny, sunny_wind))
print("\n")
print("entropy of train = ",entropy(train))
print("gain of rain_temperature = ",gain(train, rain_temperature))
print("gain of rain_humidity = ",gain(train, rain_humidity))
print("gain of rain_wind = ",gain(train, rain_wind))
print("\n")
print("entropy of tovercast = ",abs(entropy(tovercast)))